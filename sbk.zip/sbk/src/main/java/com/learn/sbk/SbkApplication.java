package com.learn.sbk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbkApplication.class, args);
	}

}
