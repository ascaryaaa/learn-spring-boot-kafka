package com.learn.sbk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbkApplicationTests {

	@Test
	void contextLoads() {
	}

}
